import requests
import psycopg2
import json

# Meta Ads API Setup
META_ACCESS_TOKEN = 'your_meta_access_token'
META_AD_ACCOUNT_ID = 'your_ad_account_id'
META_API_VERSION = 'v17.0'

# PostgreSQL Database Setup
DB_HOST = 'localhost'
DB_NAME = 'ads_dashboard'
DB_USER = 'your_db_username'
DB_PASSWORD = 'your_db_password'

def fetch_meta_ads_data():
    """Fetch basic ad insights from Meta Ads API"""
    url = f"https://graph.facebook.com/{META_API_VERSION}/act_{META_AD_ACCOUNT_ID}/insights"
    params = {
        'access_token': META_ACCESS_TOKEN,
        'fields': 'campaign_name,impressions,clicks,spend',
        'level': 'campaign',
        'limit': 10
    }
    response = requests.get(url, params=params)
    response.raise_for_status()
    return response.json()['data']

def fetch_ga4_data():
    """Mock GA4 data fetch"""
    return [
        {"pageTitle": "Landing Page", "users": 120, "sessions": 200},
        {"pageTitle": "Product Page", "users": 90, "sessions": 150}
    ]

def save_to_database(meta_data, ga4_data):
    """Save fetched data to PostgreSQL"""
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        cur = conn.cursor()
        
        # Save Meta Ads data
        for ad in meta_data:
            cur.execute("""
                INSERT INTO meta_ads (campaign_name, impressions, clicks, spend)
                VALUES (%s, %s, %s, %s)
            """, (ad['campaign_name'], ad['impressions'], ad['clicks'], ad['spend']))

        # Save GA4 data
        for entry in ga4_data:
            cur.execute("""
                INSERT INTO ga4_analytics (page_title, users, sessions)
                VALUES (%s, %s, %s)
            """, (entry['pageTitle'], entry['users'], entry['sessions']))
        
        conn.commit()
        cur.close()
        conn.close()
        print("Data saved successfully! 🚀")

    except Exception as e:
        print(f"Database error: {e}")

if __name__ == "__main__":
    print("Fetching data...")
    meta_ads = fetch_meta_ads_data()
    ga4_analytics = fetch_ga4_data()
    
    print("Saving data to database...")
    save_to_database(meta_ads, ga4_analytics)

import streamlit as st
import pandas as pd
import psycopg2

# Database connection
DB_HOST = 'localhost'
DB_NAME = 'ads_dashboard'
DB_USER = 'your_db_username'
DB_PASSWORD = 'your_db_password'

@st.cache_data
def load_data():
    """Load Meta Ads and GA4 data from the database."""
    conn = psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )
    meta_ads_df = pd.read_sql_query('SELECT * FROM meta_ads', conn)
    ga4_df = pd.read_sql_query('SELECT * FROM ga4_analytics', conn)
    conn.close()
    return meta_ads_df, ga4_df

def main():
    st.title("🚀 Open Source Ads Dashboard")

    meta_ads_df, ga4_df = load_data()

    st.header("📈 Meta Ads Performance")
    st.dataframe(meta_ads_df)

    st.header("🌐 GA4 Analytics Data")
    st.dataframe(ga4_df)

    st.sidebar.title("Summary Stats")
    st.sidebar.metric("Total Spend (€)", f"{meta_ads_df['spend'].sum():.2f}")
    st.sidebar.metric("Total Clicks", int(meta_ads_df['clicks'].sum()))
    st.sidebar.metric("Total Impressions", int(meta_ads_df['impressions'].sum()))

    st.sidebar.metric("Total Users (GA4)", int(ga4_df['users'].sum()))
    st.sidebar.metric("Total Sessions (GA4)", int(ga4_df['sessions'].sum()))

if __name__ == "__main__":
    main()
